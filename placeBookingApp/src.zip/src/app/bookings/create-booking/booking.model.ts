export interface Bookings{
id:string,
placeId:string,
userId,
placeTitle,
guestNumber:number,

}
